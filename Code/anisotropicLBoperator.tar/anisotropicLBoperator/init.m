% init to use ALB_spectrum

addpath('./tools/');